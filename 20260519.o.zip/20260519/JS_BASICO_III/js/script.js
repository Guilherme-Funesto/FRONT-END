console.log("JS externo ok")

//EXE01
function mostrarMsg(){
    let nomeExe01, paragrafoExe01;
    nomeExe01 = document.getElementById("txtExe01");
    paragrafoExe01 = document.getElementById("pExe01");
    if (nomeExe01.value != ""){
        paragrafoExe01.innerText = "Olá , " + nomeExe01.value +". Seja bem-vindo(a)!";
    } else{
        paragrafoExe01.innerHTML ="<span style='color:red'>Digite seu nome!!</span>";
    }
}

//EXE02
function trocaEstilo(){
    let btnExe02, paragrafoExe02;
    btnExe02 = document.getElementById("btnExe02");
    paragrafoExe02 = document.getElementById("pExe02");
    if (btnExe02.innerText == "Troca Estilo"){
        paragrafoExe02.style.color = 'orange';
        paragrafoExe02.style.fontSize = '30px';
        paragrafoExe02.style.background = 'red';
        btnExe02.innerText = "Retorna Estilo";
    } else{
        paragrafoExe02.style.color = '';
        paragrafoExe02.style.fontSize = '';
        paragrafoExe02.style.background = '';
        btnExe02.innerText = "Troca Estilo";
    }
}

//EXE03


//EXE04


//EXE05


//EXE06


//EXE07


//EXE08


//EXE09